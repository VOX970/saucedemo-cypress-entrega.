describe('Catálogo e gerenciamento do carrinho - SauceDemo', () => {
  beforeEach(() => {
    cy.visit('/');
    cy.get('[data-test="username"]').type('standard_user');
    cy.get('[data-test="password"]').type('secret_sauce', { log: false });
    cy.get('[data-test="login-button"]').click();
    cy.url().should('include', '/inventory.html');
  });

  it('RF-03 - apresenta a listagem de produtos após a autenticação', () => {
    cy.get('[data-test="title"]').should('have.text', 'Products');
    cy.get('.inventory_item').should('have.length', 6);
    cy.get('[data-test="inventory-item-name"]').first().should('be.visible');
    cy.get('.inventory_item_price').should('have.length', 6);
  });

  it('RF-04 - adiciona produto ao carrinho e atualiza o contador', () => {
    cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click();

    cy.get('[data-test="shopping-cart-badge"]')
      .should('be.visible')
      .and('have.text', '1');
    cy.get('[data-test="remove-sauce-labs-backpack"]').should('be.visible');
    cy.screenshot('03-produto-adicionado-carrinho');
  });

  it('RF-05 - remove produto do carrinho', () => {
    cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click();
    cy.get('[data-test="shopping-cart-link"]').click();
    cy.url().should('include', '/cart.html');
    cy.get('[data-test="inventory-item"]').should('have.length', 1);

    cy.get('[data-test="remove-sauce-labs-backpack"]').click();

    cy.get('[data-test="inventory-item"]').should('not.exist');
    cy.get('[data-test="shopping-cart-badge"]').should('not.exist');
    cy.screenshot('04-carrinho-apos-remocao');
  });

  it('RF-06 - mantém nome, descrição e preço do produto no carrinho', () => {
    let nomeProduto;
    let descricaoProduto;
    let precoProduto;

    cy.get('[data-test="inventory-item"]')
      .contains('[data-test="inventory-item-name"]', 'Sauce Labs Backpack')
      .closest('[data-test="inventory-item"]')
      .within(() => {
        cy.get('[data-test="inventory-item-name"]').invoke('text').then((texto) => {
          nomeProduto = texto.trim();
        });
        cy.get('[data-test="inventory-item-desc"]').invoke('text').then((texto) => {
          descricaoProduto = texto.trim();
        });
        cy.get('[data-test="inventory-item-price"]').invoke('text').then((texto) => {
          precoProduto = texto.trim();
        });
        cy.get('button').click();
      });

    cy.get('[data-test="shopping-cart-link"]').click();
    cy.get('[data-test="inventory-item"]').should('have.length', 1).within(() => {
      cy.get('[data-test="inventory-item-name"]').should('have.text', nomeProduto);
      cy.get('[data-test="inventory-item-desc"]').should('have.text', descricaoProduto);
      cy.get('[data-test="inventory-item-price"]').should('have.text', precoProduto);
      cy.get('[data-test="item-quantity"]').should('have.text', '1');
    });
  });
});
