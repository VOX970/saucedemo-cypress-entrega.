describe('Checkout - SauceDemo', () => {
  beforeEach(() => {
    cy.visit('/');
    cy.get('[data-test="username"]').type('standard_user');
    cy.get('[data-test="password"]').type('secret_sauce', { log: false });
    cy.get('[data-test="login-button"]').click();
    cy.url().should('include', '/inventory.html');
  });

  it('RF-07 - exige o preenchimento dos dados obrigatórios do checkout', () => {
    cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click();
    cy.get('[data-test="shopping-cart-link"]').click();
    cy.get('[data-test="checkout"]').click();
    cy.url().should('include', '/checkout-step-one.html');

    cy.get('[data-test="continue"]').click();
    cy.get('[data-test="error"]')
      .should('be.visible')
      .and('contain.text', 'First Name is required');
    cy.get('[data-test="firstName"]').type('Ana');
    cy.get('[data-test="continue"]').click();
    cy.get('[data-test="error"]')
      .should('be.visible')
      .and('contain.text', 'Last Name is required');

    cy.get('[data-test="lastName"]').type('Silva');
    cy.get('[data-test="continue"]').click();
    cy.get('[data-test="error"]')
      .should('be.visible')
      .and('contain.text', 'Postal Code is required');

    // Com todos os campos preenchidos, o sistema deve permitir avançar.
    cy.get('[data-test="postalCode"]').type('50000-000');
    cy.get('[data-test="continue"]').click();
    cy.url().should('include', '/checkout-step-two.html');
    cy.get('[data-test="title"]').should('have.text', 'Checkout: Overview');
    cy.screenshot('checkout-dados-obrigatorios-validos');
  });

  it('RF-08 - conclui a jornada E2E e apresenta a confirmação da compra', () => {
    // Seleção do produto no catálogo
    cy.get('[data-test="title"]').should('have.text', 'Products');
    cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click();
    cy.get('[data-test="shopping-cart-badge"]').should('have.text', '1');
    cy.screenshot('05-e2e-produto-selecionado');

    // Carrinho: validação do item e do valor
    cy.get('[data-test="shopping-cart-link"]').click();
    cy.url().should('include', '/cart.html');
    cy.get('[data-test="inventory-item"]').should('have.length', 1).within(() => {
      cy.get('[data-test="inventory-item-name"]').should('have.text', 'Sauce Labs Backpack');
      cy.get('[data-test="inventory-item-price"]').should('have.text', '$29.99');
      cy.get('[data-test="item-quantity"]').should('have.text', '1');
    });
    cy.get('[data-test="checkout"]').click();

    // Dados do comprador
    cy.url().should('include', '/checkout-step-one.html');
    cy.get('[data-test="firstName"]').type('Ana');
    cy.get('[data-test="lastName"]').type('Silva');
    cy.get('[data-test="postalCode"]').type('50000-000');
    cy.get('[data-test="continue"]').click();

    // Revisão do pedido e conferência dos valores
    cy.url().should('include', '/checkout-step-two.html');
    cy.get('[data-test="inventory-item-name"]').should('have.text', 'Sauce Labs Backpack');
    cy.get('[data-test="subtotal-label"]').should('contain.text', '$29.99');
    cy.get('[data-test="tax-label"]').should('be.visible');
    cy.get('[data-test="total-label"]').should('be.visible').and('contain.text', '$');
    cy.screenshot('06-e2e-revisao-pedido');

    // Confirmação da compra
    cy.get('[data-test="finish"]').click();
    cy.url().should('include', '/checkout-complete.html');
    cy.get('[data-test="complete-header"]')
      .should('be.visible')
      .and('have.text', 'Thank you for your order!');
    cy.get('[data-test="complete-text"]')
      .should('be.visible')
      .and('contain.text', 'Your order has been dispatched');
    cy.screenshot('07-e2e-compra-confirmada');
  });
});
