describe('Autenticação - SauceDemo', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('RF-01 - permite autenticação com credenciais válidas', () => {
    cy.get('[data-test="username"]').type('standard_user');
    cy.get('[data-test="password"]').type('secret_sauce', { log: false });
    cy.get('[data-test="login-button"]').click();

    cy.url().should('include', '/inventory.html');
    cy.get('[data-test="title"]').should('have.text', 'Products');
    cy.get('.inventory_list .inventory_item').should('have.length', 6);
    cy.screenshot('01-autenticacao-sucesso');
  });

  it('RF-02 - apresenta mensagem ao informar credenciais inválidas', () => {
    cy.get('[data-test="username"]').type('usuario_invalido');
    cy.get('[data-test="password"]').type('senha_incorreta', { log: false });
    cy.get('[data-test="login-button"]').click();

    cy.get('[data-test="error"]')
      .should('be.visible')
      .and('contain.text', 'Username and password do not match');
    cy.url().should('eq', `${Cypress.config('baseUrl')}/`);
    cy.screenshot('02-autenticacao-credenciais-invalidas');
  });
});
