# Automação de Testes UI e E2E — SauceDemo

Projeto individual de QA desenvolvido com **Cypress** para validar os principais fluxos de uma aplicação de comércio eletrônico: autenticação, catálogo, carrinho e checkout.

## 1. Requisitos para execução

- Node.js 18 ou superior (recomendado: versão LTS).
- npm instalado junto com o Node.js.
- Conexão com a internet para acessar `https://www.saucedemo.com`.

## 2. Instalação

1. Extraia o arquivo ZIP.
2. Abra um terminal na pasta raiz do projeto (`saucedemo-cypress`).
3. Instale as dependências:

```bash
npm install
```

## 3. Executar os testes

Para abrir a interface do Cypress e escolher os testes:

```bash
npm run cy:open
```

Para executar todos os testes automaticamente em modo headless:

```bash
npm run cy:run
```

O comando `npm test` também executa a suíte completa.

## 4. Organização dos testes

| Arquivo | Cenários cobertos |
|---|---|
| `cypress/e2e/auth/autenticacao.cy.js` | RF-01: login válido; RF-02: credenciais inválidas. |
| `cypress/e2e/carrinho/catalogo-e-carrinho.cy.js` | RF-03: listagem; RF-04: inclusão e contador; RF-05: remoção; RF-06: consistência dos dados do produto. |
| `cypress/e2e/checkout/finalizacao-compra.cy.js` | RF-07: validação dos campos obrigatórios; RF-08: jornada E2E completa até a confirmação. |

A suíte contém **8 testes automatizados**. Cada teste prepara seu próprio estado de autenticação e não depende da execução anterior.

## 5. Credenciais de teste

A aplicação SauceDemo disponibiliza usuários de demonstração. A suíte utiliza:

- Usuário: `standard_user`
- Senha: `secret_sauce`

O cenário negativo utiliza credenciais propositalmente inválidas.

## 6. Evidências e relatórios

Durante a execução, os testes salvam capturas de tela nos pontos relevantes por meio de `cy.screenshot()`. Em execução headless, os arquivos são armazenados em `cypress/screenshots/`. O Cypress também registra vídeos dos arquivos de teste em `cypress/videos/` (configuração habilitada).

As capturas e os vídeos são gerados localmente quando a suíte é executada. **Este pacote contém a implementação e a configuração para produzir as evidências; os resultados reais de execução devem ser gerados no ambiente de quem executar o projeto.** Não foram incluídas capturas fictícias.

## 7. Critérios técnicos adotados

- Cypress para automação UI/E2E.
- Seletores `data-test` disponibilizados pela aplicação, priorizados por serem mais estáveis que seletores dependentes de CSS visual.
- Assertions explícitas para URLs, títulos, mensagens, quantidade de itens, contador, dados e valores do pedido.
- Cenários positivos e negativos.
- `beforeEach` para preparar a sessão de cada teste de forma independente.
- Sem Page Object Model, fixtures ou comandos personalizados, conforme permitido e solicitado no enunciado.

## 8. Escopo e observação

Os testes dependem da disponibilidade da aplicação pública SauceDemo e de conexão com a internet. O fluxo E2E utiliza o usuário de demonstração `standard_user` e conclui um pedido fictício dentro do ambiente de demonstração; nenhuma compra real é realizada.
